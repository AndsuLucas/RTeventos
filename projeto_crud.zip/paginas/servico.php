<?php 
    include "includes/conexao.php";
    $msg_erro = "";
if(isset($_GET['excluir'])){
    $excluir = (int)$_GET['excluir'];
    $sql = "DELETE from servico WHERE id_servico = $excluir";
    $res = mysqli_query($conexao, $sql);
}

if(isset($_GET['editar'])){
    echo "passou aqui";
    $editar = (int)$_GET["editar"];
    $sql= "SELECT * FROM servico WHERE id_servico = $editar";
    $res = mysqli_query($conexao, $sql);
    $dados_editar = mysqli_fetch_all($res, MYSQLI_ASSOC);

}


if(isset($_POST['btnacao'])){
    $descricao = $_POST['descricao'];
    $observacao = $_POST['observacao'];
    $id_servico = (int)$_POST['id_servico'];

    if(strlen(trim($descricao))==0){
        $msg_erro = "Informe o campos descrição";
    }
    if(strlen(trim($msg_erro))==0){

        if($id_servico == 0){
            $sql = "INSERT INTO servico (descricao, observacao) 
                VALUES ('$descricao', '$observacao')";
        }else{
            echo "update";
            $sql = "UPDATE servico SET descricao = '$descricao', 
                observacao = '$observacao' WHERE id_servico = $id_servico ";
        }
        $res = mysqli_query($conexao, $sql);
    }
}

    $sql= "SELECT * FROM servico";
    $res = mysqli_query($conexao, $sql);
    $dados = mysqli_fetch_all($res, MYSQLI_ASSOC);

    

?>

<div id="msg_erro"><?=$msg_erro?></div>

<form name="frm_servico" method="POST" action="">
    <lable>Descrição:</lable> <br>
    <input type="text" name="descricao" value="<?=$dados_editar[0]['descricao']?>"> <br>

    <lable>Observação:</lable> <br>
    <input type="text" name="observacao" value="<?=$dados_editar[0]['observacao']?>"> <br>
    <input type="hidden" name="id_servico" value="<?=$dados_editar[0]['id_servico']?>">
    <input type="submit" name="btnacao" value="Gravar"> <br>
</form>

<table border=2>
    <tr>
        <th>#</th>
        <th>Descrição</th>
        <th>Observação</th>
        <th colspan="2">Ações</th>
        <?php foreach($dados as $chave => $valores){
             echo "<tr>";
             echo "<td></td>";
              echo "<td>$valores[descricao]</td>";
              echo "<td>$valores[observacao]</td>";
              echo "<td><a href='?pagina=servico&editar=$valores[id_servico]'>Editar</a></td>";
              echo "<td><a href='?pagina=servico&excluir=$valores[id_servico]'>Excluir</a></td>";
             echo "</tr>";

        }
        ?>
    </tr>

</table>
