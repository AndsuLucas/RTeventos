<?php 


echo "Informações aparecem aqui";








?>