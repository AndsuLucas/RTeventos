<?php 
    include "includes/conexao.php";
    $msg_erro = "";

if(isset($_POST['btnacao'])){
    $descricao = $_POST['descricao'];
    $observacao = $_POST['observacao'];

    //echo "obs = $observacao --- desc = $descricao <br> ";

    if(strlen(trim($descricao))==0){
        $msg_erro = "Informe o campos descrição";
    }
    if(strlen(trim($msg_erro))==0){
        $sql = "INSERT INTO servico (descricao, observacao) 
                VALUES ('$descricao', '$observacao')";
        $res = mysqli_query($conexao, $sql);
    }
    //echo $sql;
}

    $sql= "SELECT * FROM servico";
    $res = mysqli_query($conexao, $sql);
    $dados = mysqli_fetch_all($res, MYSQLI_ASSOC);
/*
    echo "<pre>";
        print_r($dados);
    echo "</pre>";
*/
?>

<div id="msg_erro"><?=$msg_erro?></div>

<form name="frm_servico" method="POST" action="">
    <lable>Descrição:</lable> <br>
    <input type="text" name="descricao" value=""> <br>

    <lable>Observação:</lable> <br>
    <input type="text" name="observacao" value=""> <br>

    <input type="submit" name="btnacao" value="Gravar"> <br>
</form>

<table border=2>
    <tr>
        <th>#</th>
        <th>Descrição</th>
        <th>Observação</th>
        <th colspan="2">Ações</th>
        <?php foreach($dados as $chave => $valores){
             echo "<tr>";
             echo "<td></td>";
              echo "<td>$valores[descricao]</td>";
              echo "<td>$valores[observacao]</td>";
              echo "<td>Editar</td>";
              echo "<td>Excluir</td>";
             echo "</tr>";

        }
        ?>
    </tr>

</table>
