<?php 

$conexao  =  mysqli_connect("localhost:3307","root","","rteventos");
/*
    if($conexao){
    echo "<br><br><br>conectou...";
    }else{
    echo "falha";
    }
*/



?>